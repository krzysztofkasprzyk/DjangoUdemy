@echo off
setlocal

set MAVEN_VERSION=3.9.14
set ARCHIVE=%USERPROFILE%\Downloads\apache-maven-%MAVEN_VERSION%-bin.tar.gz
set INSTALL_BASE=%USERPROFILE%\tools\maven
set EXTRACT_DIR=%INSTALL_BASE%
set MAVEN_HOME=%INSTALL_BASE%\apache-maven-%MAVEN_VERSION%

echo.
echo ===== Sprawdzam Java =====
java -version
if errorlevel 1 (
    echo [BLAD] Java nie jest dostepna w PATH.
    exit /b 1
)

echo.
echo ===== Sprawdzam archiwum =====
if not exist "%ARCHIVE%" (
    echo [BLAD] Nie znaleziono pliku:
    echo %ARCHIVE%
    exit /b 1
)

echo.
echo ===== Tworze katalog docelowy =====
if not exist "%INSTALL_BASE%" mkdir "%INSTALL_BASE%"

echo.
echo ===== Usuwam poprzednia instalacje =====
if exist "%MAVEN_HOME%" rmdir /s /q "%MAVEN_HOME%"

echo.
echo ===== Rozpakowuje Maven z tar.gz =====
tar -xzf "%ARCHIVE%" -C "%EXTRACT_DIR%"
if errorlevel 1 (
    echo [BLAD] Nie udalo sie rozpakowac archiwum przez tar.
    echo Sprobuj uruchomic ten skrypt w nowszym CMD / PowerShell albo sprawdz, czy komenda tar dziala.
    exit /b 1
)

echo.
echo ===== Ustawiam MAVEN_HOME =====
setx MAVEN_HOME "%MAVEN_HOME%" >nul

echo.
echo ===== Dodaje Maven do PATH uzytkownika =====
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p=[Environment]::GetEnvironmentVariable('Path','User');" ^
  "if ($p -notlike '*%MAVEN_HOME%\bin*') {[Environment]::SetEnvironmentVariable('Path', $p + ';%MAVEN_HOME%\bin', 'User')}"

echo.
echo ===== GOTOWE =====
echo Zamknij to okno, otworz NOWE CMD i wpisz:
echo mvn -version
echo.
pause