﻿$env:NOTIFICATION_CHANNEL = "email"
$env:TELEGRAM_POLLING_ENABLED = "false"
$env:START_MONITORING_ON_BOOT = "true"

$env:OPENAI_API_KEY = "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"
$env:OPENAI_MODEL = "gpt-5-mini"

$env:SCAN_INTERVAL_SECONDS = "90"
$env:DEFAULT_KEYWORDS = "uszkodzony,uszkodzona,uszkodzone,do naprawy,nietestowany,nietestowane"
$env:DEFAULT_PRICE_FROM = ""
$env:DEFAULT_PRICE_TO = "1500"
$env:DEFAULT_LOCATION_FILTER = ""
$env:SEARCH_RESULT_LIMIT = "18"
$env:MARKET_REFERENCE_LIMIT = "8"
$env:MAX_SEEN_OFFERS = "500"

$env:SMTP_HOST = "smtp.gmail.com"
$env:SMTP_PORT = "587"
$env:SMTP_FROM = "kiirasallegro@gmail.com"
$env:SMTP_USERNAME = "kiirasallegro@gmail.com"
$env:SMTP_PASSWORD = "renj slyp bcar xcdf"
$env:ALERT_EMAIL_TO = "kiirasallegro@gmail.com"
$env:SMTP_STARTTLS = "true"
$env:SMTP_SSL = "false"

mvn clean package
if ($LASTEXITCODE -ne 0) {
    throw "Build nie powiodl sie."
}

java "-Djavax.net.ssl.trustStoreType=Windows-ROOT" -jar target\olx-electro-hunter-2.0.0.jar

