$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Test-Command {
    param([string]$Name)
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Add-ToPathIfMissing {
    param([string]$PathToAdd)

    if ([string]::IsNullOrWhiteSpace($PathToAdd)) {
        return
    }

    $parts = ($env:Path -split ';') | Where-Object { $_ -and $_.Trim() -ne "" }
    if ($parts -notcontains $PathToAdd) {
        $env:Path = "$PathToAdd;$env:Path"
    }
}

function Ensure-Java21 {
    $hasJava21 = $false

    if (Test-Command "java") {
        try {
            $javaVersionOutput = (& java -version 2>&1) | Out-String
            if ($javaVersionOutput -match 'version "21\.') {
                $hasJava21 = $true
            }
        } catch {
        }
    }

    if ($hasJava21) {
        Write-Host "Java 21 already available." -ForegroundColor Green
        return
    }

    if (-not (Test-Command "winget")) {
        throw "Brak winget. Na docelowym Windowsie potrzebujesz winget albo recznie zainstalowanej Javy 21."
    }

    Write-Step "Installing Java 21 via winget"
    & winget install --id Oracle.JDK.21 --exact --accept-package-agreements --accept-source-agreements --silent

    $javaHomes = @(
        "C:\Program Files\Java\jdk-21\bin",
        "C:\Program Files\Java\jdk-21.0.9\bin",
        "C:\Program Files\Java\jdk-21.0.10\bin"
    )

    foreach ($candidate in $javaHomes) {
        if (Test-Path $candidate) {
            Add-ToPathIfMissing $candidate
        }
    }

    $oracleJdks = Get-ChildItem "C:\Program Files\Java" -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "jdk-21*" } |
        Sort-Object Name -Descending

    if ($oracleJdks) {
        Add-ToPathIfMissing (Join-Path $oracleJdks[0].FullName "bin")
    }

    if (-not (Test-Command "java")) {
        throw "Java 21 nie zostala poprawnie odnaleziona po instalacji."
    }
}

function Ensure-Maven {
    if (Test-Command "mvn") {
        Write-Host "Maven already available." -ForegroundColor Green
        return
    }

    Write-Step "Installing portable Maven"
    $mavenVersion = "3.9.14"
    $toolsDir = Join-Path $projectRoot ".tools"
    $mavenDir = Join-Path $toolsDir "apache-maven-$mavenVersion"
    $mavenZip = Join-Path $toolsDir "apache-maven-$mavenVersion-bin.zip"
    $mavenUrl = "https://archive.apache.org/dist/maven/maven-3/$mavenVersion/binaries/apache-maven-$mavenVersion-bin.zip"

    New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null

    if (-not (Test-Path $mavenDir)) {
        Invoke-WebRequest -Uri $mavenUrl -OutFile $mavenZip
        Expand-Archive -Path $mavenZip -DestinationPath $toolsDir -Force
    }

    Add-ToPathIfMissing (Join-Path $mavenDir "bin")

    if (-not (Test-Command "mvn")) {
        throw "Maven nie zostal poprawnie przygotowany."
    }
}

Write-Step "Preparing local prerequisites"
Ensure-Java21
Ensure-Maven

Write-Step "Starting configured mail-only runner"
& powershell -ExecutionPolicy Bypass -File (Join-Path $projectRoot "run-email-only.ps1")
