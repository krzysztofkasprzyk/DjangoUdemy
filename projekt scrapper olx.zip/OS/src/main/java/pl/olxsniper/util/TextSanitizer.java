package pl.olxsniper.util;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public final class TextSanitizer {
    private static final List<String> DAMAGE_HINTS = List.of(
            "uszkodz",
            "do napraw",
            "nietest",
            "na czesci",
            "na części",
            "nie wlacza",
            "nie włącza",
            "brak obrazu",
            "zbity",
            "pekniety",
            "peknieta",
            "pęk",
            "martwy",
            "nie dziala",
            "nie działa"
    );

    private static final Set<String> STOP_WORDS = Set.of(
            "uszkodzony", "uszkodzona", "uszkodzone", "do", "naprawy", "nietestowany", "nietestowane",
            "nietestowana", "na", "czesci", "części", "okazja", "tanio", "mega", "super"
    );

    private TextSanitizer() {
    }

    public static String toOlxQuerySlug(String value) {
        return normalize(value)
                .replaceAll("[^a-z0-9\\s-]", " ")
                .trim()
                .replaceAll("\\s+", "-");
    }

    public static boolean containsDamageHint(String value) {
        String normalized = normalize(value);
        return DAMAGE_HINTS.stream().anyMatch(normalized::contains);
    }

    public static String cleanProductSearchQuery(String value) {
        List<String> tokens = Arrays.stream(normalize(value).split("\\s+"))
                .filter(token -> !token.isBlank())
                .filter(token -> token.length() > 1)
                .filter(token -> !STOP_WORDS.contains(token))
                .distinct()
                .limit(8)
                .toList();
        return String.join(" ", tokens);
    }

    public static boolean looksRelevantToQuery(String query, String title) {
        Set<String> queryTokens = tokenize(cleanProductSearchQuery(query));
        if (queryTokens.isEmpty()) {
            return true;
        }

        Set<String> titleTokens = tokenize(title);
        long overlap = queryTokens.stream().filter(titleTokens::contains).count();
        long minimumOverlap = Math.min(2, queryTokens.size());
        return overlap >= minimumOverlap;
    }

    public static Set<String> tokenize(String value) {
        return Arrays.stream(normalize(value).split("\\s+"))
                .filter(token -> !token.isBlank())
                .filter(token -> token.length() > 1)
                .collect(Collectors.toSet());
    }

    private static String normalize(String value) {
        String normalized = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        return normalized.toLowerCase(Locale.ROOT);
    }
}
