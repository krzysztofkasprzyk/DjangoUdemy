package pl.olxsniper.util;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;

public final class SeenOfferCache {
    private final int maxSize;
    private final Deque<String> order = new ArrayDeque<>();
    private final Set<String> values = new HashSet<>();

    public SeenOfferCache(int maxSize) {
        this.maxSize = maxSize;
    }

    public synchronized boolean markIfNew(String url) {
        if (values.contains(url)) {
            return false;
        }

        values.add(url);
        order.addLast(url);

        while (order.size() > maxSize) {
            String oldest = order.removeFirst();
            values.remove(oldest);
        }

        return true;
    }
}
