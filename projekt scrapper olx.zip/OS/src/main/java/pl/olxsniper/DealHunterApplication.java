package pl.olxsniper;

import pl.olxsniper.config.AppConfig;
import pl.olxsniper.config.ChatSettings;
import pl.olxsniper.domain.ListingSummary;
import pl.olxsniper.domain.OpportunityReport;
import pl.olxsniper.service.EmailClient;
import pl.olxsniper.service.NotificationDispatcher;
import pl.olxsniper.service.OlxClient;
import pl.olxsniper.service.OpenAiAnalyzer;
import pl.olxsniper.service.OpportunityFormatter;
import pl.olxsniper.service.OpportunityService;
import pl.olxsniper.service.TelegramClient;
import pl.olxsniper.service.TelegramUpdate;
import pl.olxsniper.util.SeenOfferCache;

import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class DealHunterApplication {
    private static final Logger LOGGER = Logger.getLogger(DealHunterApplication.class.getName());

    private final AppConfig config;
    private final TelegramClient telegramClient;
    private final NotificationDispatcher notificationDispatcher;
    private final OlxClient olxClient;
    private final OpenAiAnalyzer openAiAnalyzer;
    private final OpportunityService opportunityService;
    private final OpportunityFormatter opportunityFormatter;

    private final Map<Long, ChatSession> sessions = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final ExecutorService scanExecutor = Executors.newFixedThreadPool(3);

    private volatile long updateOffset = 0L;

    public DealHunterApplication(AppConfig config) {
        this.config = config;
        this.telegramClient = config.telegramBotToken() == null || config.telegramBotToken().isBlank()
                ? null
                : new TelegramClient(config.telegramBotToken());
        this.olxClient = new OlxClient();
        this.openAiAnalyzer = new OpenAiAnalyzer(config);
        this.opportunityService = new OpportunityService(olxClient, openAiAnalyzer, config.marketReferenceLimit());
        this.opportunityFormatter = new OpportunityFormatter();
        this.notificationDispatcher = new NotificationDispatcher(
                config.notificationMode(),
                telegramClient,
                config.notificationMode().includesEmail() ? new EmailClient(config.emailSettings()) : null
        );
    }

    public void start() {
        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown));
        LOGGER.info(() -> "Starting OLX Electro Hunter with model " + config.openAiModel()
                + " and channel " + config.notificationMode());

        scheduler.scheduleWithFixedDelay(
                this::scanActiveChats,
                config.scanInterval().toSeconds(),
                config.scanInterval().toSeconds(),
                TimeUnit.SECONDS
        );

        if (config.telegramPollingEnabled()) {
            pollTelegramForever();
        } else {
            ensureHeadlessSession();
            waitForever();
        }
    }

    private void pollTelegramForever() {
        while (true) {
            try {
                List<TelegramUpdate> updates = telegramClient.getUpdates(updateOffset, config.telegramLongPollSeconds());
                for (TelegramUpdate update : updates) {
                    updateOffset = Math.max(updateOffset, update.updateId() + 1);
                    handleUpdate(update);
                }
            } catch (Exception exception) {
                LOGGER.log(Level.WARNING, "Telegram polling failed", exception);
                sleepQuietly(config.reconnectDelay().toSeconds());
            }
        }
    }

    private void handleUpdate(TelegramUpdate update) {
        if (update.text() == null || update.text().isBlank()) {
            return;
        }

        ChatSession session = sessions.computeIfAbsent(
                update.chatId(),
                chatId -> new ChatSession(chatId, new ChatSettings(config), new SeenOfferCache(config.maxSeenOffers()))
        );

        String rawText = update.text().trim();
        String normalizedCommand = normalizeCommand(rawText);

        switch (normalizedCommand) {
            case "/start" -> handleStart(session);
            case "/stop" -> handleStop(session);
            case "/status" -> telegramClient.sendHtmlMessage(session.chatId(), buildStatusMessage(session));
            case "/help" -> telegramClient.sendHtmlMessage(session.chatId(), helpMessage());
            case "/scan" -> {
                telegramClient.sendHtmlMessage(session.chatId(), "Uruchamiam reczny skan.");
                scanExecutor.submit(() -> scanSession(session, true));
            }
            case "/setup" -> handleSetup(session, rawText);
            default -> telegramClient.sendHtmlMessage(
                    session.chatId(),
                    "Nie znam tej komendy. Uzyj <b>/help</b>, zeby zobaczyc dostepne opcje."
            );
        }
    }

    private void handleStart(ChatSession session) {
        session.settings().setActive(true);
        telegramClient.sendHtmlMessage(
                session.chatId(),
                "Monitoring zostal wlaczony. Pierwszy skan zbuduje baze referencyjna bez spamu, kolejne beda lapac nowe okazje."
        );
        scanExecutor.submit(() -> scanSession(session, false));
    }

    private void handleStop(ChatSession session) {
        session.settings().setActive(false);
        telegramClient.sendHtmlMessage(session.chatId(), "Monitoring zostal zatrzymany.");
    }

    private void handleSetup(ChatSession session, String rawText) {
        String[] parts = rawText.split("\\s+", 3);
        if (parts.length < 3) {
            telegramClient.sendHtmlMessage(
                    session.chatId(),
                    "Skladnia: <b>/setup [keywords|priceFrom|priceTo|location] [wartosc]</b>"
            );
            return;
        }

        String option = parts[1].toLowerCase(Locale.ROOT);
        String value = parts[2].trim();
        ChatSettings settings = session.settings();

        try {
            switch (option) {
                case "keywords" -> {
                    settings.setKeywordsFromCsv(value);
                    telegramClient.sendHtmlMessage(
                            session.chatId(),
                            "Frazy monitoringu ustawione na: <b>" + escape(settings.keywordsAsDisplayString()) + "</b>"
                    );
                }
                case "pricefrom" -> {
                    settings.setPriceFrom(parseNullableInteger(value));
                    telegramClient.sendHtmlMessage(
                            session.chatId(),
                            "Minimalna cena ustawiona na: <b>" + displayNullablePrice(settings.priceFrom()) + "</b>"
                    );
                }
                case "priceto" -> {
                    settings.setPriceTo(parseNullableInteger(value));
                    telegramClient.sendHtmlMessage(
                            session.chatId(),
                            "Maksymalna cena ustawiona na: <b>" + displayNullablePrice(settings.priceTo()) + "</b>"
                    );
                }
                case "location" -> {
                    settings.setLocationFilter("-".equals(value) ? null : value);
                    telegramClient.sendHtmlMessage(
                            session.chatId(),
                            "Filtr lokalizacji ustawiony na: <b>" + escape(settings.locationDisplayValue()) + "</b>"
                    );
                }
                default -> telegramClient.sendHtmlMessage(
                        session.chatId(),
                        "Nie obsluguje tej opcji setup. Uzyj <b>/help</b>."
                );
            }
        } catch (IllegalArgumentException exception) {
            telegramClient.sendHtmlMessage(session.chatId(), escape(exception.getMessage()));
        }
    }

    private void scanActiveChats() {
        long activeSessions = sessions.values().stream()
                .filter(session -> session.settings().active())
                .count();

        if (activeSessions > 0) {
            LOGGER.info(() -> "Starting scheduled scan for " + activeSessions + " active session(s).");
        }

        sessions.values().stream()
                .filter(session -> session.settings().active())
                .forEach(session -> scanExecutor.submit(() -> scanSession(session, false)));
    }

    private void scanSession(ChatSession session, boolean manualTrigger) {
        if (!session.scanInProgress().compareAndSet(false, true)) {
            if (manualTrigger) {
                telegramClient.sendHtmlMessage(session.chatId(), "Skan juz trwa, daj mi chwile.");
            }
            return;
        }

        try {
            LOGGER.info(() -> "Scanning chatId=" + session.chatId()
                    + " keywords=" + session.settings().keywordsAsDisplayString()
                    + " priceFrom=" + session.settings().priceFrom()
                    + " priceTo=" + session.settings().priceTo()
                    + " location=" + session.settings().locationDisplayValue());

            List<ListingSummary> listings = olxClient.searchDamagedListings(session.settings(), config.searchResultLimit());
            session.setLastScanAt(Instant.now());
            LOGGER.info(() -> "Fetched " + listings.size() + " listing(s) for chatId=" + session.chatId());

            if (!session.initialized()) {
                listings.forEach(listing -> session.seenOfferCache().markIfNew(listing.url()));
                session.setInitialized(true);
                session.setLastScanSummary("Pierwszy skan zapisal " + listings.size() + " ofert jako baze odniesienia.");
                LOGGER.info(() -> "Initial snapshot saved for chatId=" + session.chatId() + " offers=" + listings.size());

                if (telegramClient != null && (manualTrigger || session.settings().active())) {
                    telegramClient.sendHtmlMessage(
                            session.chatId(),
                            "Pierwszy skan zakonczony. Zapisalem <b>" + listings.size() + "</b> aktualnych ofert jako punkt startowy."
                    );
                }
                return;
            }

            int newListings = 0;
            int notifications = 0;

            for (ListingSummary listing : listings) {
                if (!session.seenOfferCache().markIfNew(listing.url())) {
                    continue;
                }

                newListings++;
                OpportunityReport report = opportunityService.inspect(listing);
                if (report.shouldNotify()) {
                    LOGGER.info(() -> "Opportunity found: score=" + report.dealScore()
                            + " verdict=" + report.verdict()
                            + " title=" + report.listing().summary().title());
                    notificationDispatcher.sendAlert(
                            session.chatId(),
                            opportunityFormatter.subjectFor(report),
                            opportunityFormatter.format(report)
                    );
                    notifications++;
                } else {
                    LOGGER.info(() -> "Skipped listing after analysis: score=" + report.dealScore()
                            + " title=" + report.listing().summary().title());
                }
            }

            session.setLastScanSummary("Nowe oferty: " + newListings + ", wyslane alerty: " + notifications + ".");
            LOGGER.info(() -> "Scan finished for chatId=" + session.chatId()
                    + " newListings=" + newListings
                    + " notifications=" + notifications);

            if (manualTrigger && notifications == 0) {
                telegramClient.sendHtmlMessage(
                            session.chatId(),
                        "Brak nowych mega okazji w tej chwili. " + escape(session.lastScanSummary())
                );
            }
        } catch (Exception exception) {
            session.setLastScanSummary("Skan zakonczyl sie bledem: " + exception.getMessage());
            LOGGER.log(Level.WARNING, "Scan failed for chat " + session.chatId(), exception);

            if (manualTrigger) {
                telegramClient.sendHtmlMessage(
                        session.chatId(),
                        "Skan nie udal sie tym razem: <b>" + escape(safeMessage(exception)) + "</b>"
                );
            }
        } finally {
            session.scanInProgress().set(false);
        }
    }

    private String buildStatusMessage(ChatSession session) {
        ChatSettings settings = session.settings();

        StringBuilder builder = new StringBuilder();
        builder.append("<b>Status monitoringu</b>\n");
        builder.append("Aktywny: <b>").append(settings.active() ? "tak" : "nie").append("</b>\n");
        builder.append("Frazy: <b>").append(escape(settings.keywordsAsDisplayString())).append("</b>\n");
        builder.append("Cena od: <b>").append(displayNullablePrice(settings.priceFrom())).append("</b>\n");
        builder.append("Cena do: <b>").append(displayNullablePrice(settings.priceTo())).append("</b>\n");
        builder.append("Lokalizacja: <b>").append(escape(settings.locationDisplayValue())).append("</b>\n");
        builder.append("Powiadomienia: <b>").append(config.notificationMode()).append("</b>\n");
        builder.append("Polling Telegram: <b>").append(config.telegramPollingEnabled() ? "tak" : "nie").append("</b>\n");
        builder.append("AI: <b>").append(config.aiEnabled() ? config.openAiModel() : "fallback heurystyczny").append("</b>\n");

        if (session.lastScanAt() != null) {
            builder.append("Ostatni skan: <b>").append(escape(session.lastScanAt().toString())).append("</b>\n");
        }
        if (session.lastScanSummary() != null) {
            builder.append("Ostatni wynik: <b>").append(escape(session.lastScanSummary())).append("</b>");
        }

        return builder.toString();
    }

    private String helpMessage() {
        return """
                <b>OLX Electro Hunter</b>
                /start - wlacza monitoring
                /stop - zatrzymuje monitoring
                /status - pokazuje aktualne ustawienia
                /scan - odpala reczny skan teraz
                /setup keywords uszkodzony,do naprawy,nietestowany - ustawia monitorowane frazy
                /setup priceFrom 100 - ustawia dolny prog ceny
                /setup priceTo 1200 - ustawia gorny prog ceny
                /setup location warszawa - filtruje po lokalizacji
                /setup location - - czysci filtr lokalizacji
                """;
    }

    private String normalizeCommand(String rawText) {
        String firstToken = rawText.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int mentionIndex = firstToken.indexOf('@');
        if (mentionIndex >= 0) {
            firstToken = firstToken.substring(0, mentionIndex);
        }
        return firstToken;
    }

    private Integer parseNullableInteger(String value) {
        if ("-".equals(value)) {
            return null;
        }
        return Integer.parseInt(value);
    }

    private String displayNullablePrice(Integer value) {
        return value == null ? "brak" : value + " PLN";
    }

    private String escape(String value) {
        if (value == null) {
            return "";
        }
        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    private String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
    }

    private void sleepQuietly(long seconds) {
        try {
            TimeUnit.SECONDS.sleep(seconds);
        } catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
        }
    }

    private void shutdown() {
        scheduler.shutdownNow();
        scanExecutor.shutdownNow();
    }

    private void ensureHeadlessSession() {
        ChatSession session = sessions.computeIfAbsent(
                0L,
                chatId -> new ChatSession(chatId, new ChatSettings(config), new SeenOfferCache(config.maxSeenOffers()))
        );
        session.settings().setActive(config.startupMonitoringEnabled());
        session.setInitialized(false);
        session.setLastScanSummary("Tryb headless uruchomiony. Monitoring aktywny: " + config.startupMonitoringEnabled());
        LOGGER.info(() -> "Running in headless mode without Telegram polling. Active="
                + config.startupMonitoringEnabled()
                + ", keywords=" + session.settings().keywordsAsDisplayString()
                + ", priceFrom=" + session.settings().priceFrom()
                + ", priceTo=" + session.settings().priceTo());
    }

    private void waitForever() {
        while (true) {
            sleepQuietly(config.reconnectDelay().toSeconds());
        }
    }

    private static final class ChatSession {
        private final long chatId;
        private final ChatSettings settings;
        private final SeenOfferCache seenOfferCache;
        private final AtomicBoolean scanInProgress = new AtomicBoolean(false);

        private volatile boolean initialized;
        private volatile Instant lastScanAt;
        private volatile String lastScanSummary;

        private ChatSession(long chatId, ChatSettings settings, SeenOfferCache seenOfferCache) {
            this.chatId = chatId;
            this.settings = settings;
            this.seenOfferCache = seenOfferCache;
        }

        private long chatId() {
            return chatId;
        }

        private ChatSettings settings() {
            return settings;
        }

        private SeenOfferCache seenOfferCache() {
            return seenOfferCache;
        }

        private AtomicBoolean scanInProgress() {
            return scanInProgress;
        }

        private boolean initialized() {
            return initialized;
        }

        private void setInitialized(boolean initialized) {
            this.initialized = initialized;
        }

        private Instant lastScanAt() {
            return lastScanAt;
        }

        private void setLastScanAt(Instant lastScanAt) {
            this.lastScanAt = lastScanAt;
        }

        private String lastScanSummary() {
            return lastScanSummary;
        }

        private void setLastScanSummary(String lastScanSummary) {
            this.lastScanSummary = lastScanSummary;
        }
    }
}
