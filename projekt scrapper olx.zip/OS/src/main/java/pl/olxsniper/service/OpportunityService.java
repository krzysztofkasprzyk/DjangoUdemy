package pl.olxsniper.service;

import pl.olxsniper.domain.AiAssessment;
import pl.olxsniper.domain.ListingDetails;
import pl.olxsniper.domain.ListingSummary;
import pl.olxsniper.domain.MarketSnapshot;
import pl.olxsniper.domain.OpportunityReport;

import java.util.Locale;

public final class OpportunityService {
    private final OlxClient olxClient;
    private final OpenAiAnalyzer openAiAnalyzer;
    private final int marketReferenceLimit;

    public OpportunityService(OlxClient olxClient, OpenAiAnalyzer openAiAnalyzer, int marketReferenceLimit) {
        this.olxClient = olxClient;
        this.openAiAnalyzer = openAiAnalyzer;
        this.marketReferenceLimit = marketReferenceLimit;
    }

    public OpportunityReport inspect(ListingSummary listingSummary) {
        ListingDetails listingDetails = olxClient.fetchListingDetails(listingSummary);
        AiAssessment assessment = openAiAnalyzer.analyze(listingDetails);
        MarketSnapshot marketSnapshot = olxClient.buildMarketSnapshot(assessment.productSearchQuery(), marketReferenceLimit);
        return score(listingDetails, assessment, marketSnapshot);
    }

    private OpportunityReport score(ListingDetails listingDetails, AiAssessment assessment, MarketSnapshot marketSnapshot) {
        int askingPrice = listingDetails.summary().price();
        double marketMedian = marketSnapshot.medianPrice() > 0 ? marketSnapshot.medianPrice() : marketSnapshot.averagePrice();

        int optimisticProfit = marketMedian > 0
                ? (int) Math.round(marketMedian - askingPrice - assessment.repairCostMinPln())
                : -assessment.repairCostMinPln();
        int conservativeProfit = marketMedian > 0
                ? (int) Math.round(marketMedian - askingPrice - assessment.repairCostMaxPln())
                : -assessment.repairCostMaxPln();

        int score = 50;

        if (marketMedian > 0) {
            double priceRatio = askingPrice / marketMedian;
            score += clamp((int) Math.round((1.0 - priceRatio) * 45.0), -15, 30);
        } else {
            score -= 12;
        }

        score += clamp(conservativeProfit / 25, -20, 20);
        score += switch (assessment.repairability().toUpperCase(Locale.ROOT)) {
            case "EASY" -> 18;
            case "MODERATE" -> 8;
            case "HARD" -> -10;
            case "UNECONOMICAL" -> -25;
            default -> 0;
        };
        score += switch (assessment.confidence().toUpperCase(Locale.ROOT)) {
            case "HIGH" -> 8;
            case "MEDIUM" -> 3;
            default -> -6;
        };
        score += Math.min(assessment.workingValuePoints().size() * 3, 9);
        score -= Math.min(assessment.redFlags().size() * 4, 16);

        if (marketSnapshot.sampleSize() >= 5) {
            score += 6;
        } else if (marketSnapshot.sampleSize() >= 3) {
            score += 2;
        } else {
            score -= 8;
        }

        score = clamp(score, 0, 100);

        String verdict = verdictFor(score, conservativeProfit);
        boolean shouldNotify = (score >= 75 && conservativeProfit >= 50 && marketSnapshot.sampleSize() >= 3)
                || (score >= 85 && conservativeProfit >= 0);

        return new OpportunityReport(
                listingDetails,
                assessment,
                marketSnapshot,
                score,
                conservativeProfit,
                optimisticProfit,
                verdict,
                shouldNotify
        );
    }

    private String verdictFor(int score, int conservativeProfit) {
        if (score >= 85 && conservativeProfit >= 100) {
            return "MEGA OKAZJA";
        }
        if (score >= 75) {
            return "WARTA UWAGI";
        }
        if (score >= 60) {
            return "GRANICZNA";
        }
        return "RACZEJ ODPUSC";
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
