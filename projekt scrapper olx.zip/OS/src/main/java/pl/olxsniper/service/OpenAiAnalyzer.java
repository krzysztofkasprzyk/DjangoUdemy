package pl.olxsniper.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import pl.olxsniper.config.AppConfig;
import pl.olxsniper.domain.AiAssessment;
import pl.olxsniper.domain.ListingDetails;
import pl.olxsniper.util.TextSanitizer;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class OpenAiAnalyzer {
    private static final URI RESPONSES_URI = URI.create("https://api.openai.com/v1/responses");

    private final AppConfig config;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(20))
            .build();

    public OpenAiAnalyzer(AppConfig config) {
        this.config = config;
    }

    public AiAssessment analyze(ListingDetails listingDetails) {
        if (!config.aiEnabled()) {
            return heuristicAssessment(listingDetails, "Analiza heurystyczna, bo OPENAI_API_KEY nie jest ustawiony.");
        }

        try {
            ObjectNode requestBody = objectMapper.createObjectNode();
            requestBody.put("model", config.openAiModel());
            requestBody.put("instructions", systemPrompt());
            requestBody.put("input", buildPrompt(listingDetails));
            requestBody.set("text", buildTextFormat());

            HttpRequest request = HttpRequest.newBuilder(RESPONSES_URI)
                    .header("Authorization", "Bearer " + config.openAiApiKey())
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(60))
                    .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(requestBody), StandardCharsets.UTF_8))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            JsonNode root = objectMapper.readTree(response.body());

            if (response.statusCode() >= 300) {
                throw new IllegalStateException(root.path("error").path("message").asText("OpenAI API error"));
            }

            String outputText = root.path("output_text").asText("");
            if (outputText.isBlank()) {
                throw new IllegalStateException("OpenAI nie zwrocil output_text.");
            }

            AiAssessment assessment = objectMapper.readValue(outputText, AiAssessment.class);
            return normalizeAssessment(assessment, listingDetails, "Analiza AI.");
        } catch (Exception exception) {
            return heuristicAssessment(
                    listingDetails,
                    "Analiza heurystyczna po bledzie OpenAI: " + exception.getClass().getSimpleName()
            );
        }
    }

    private String systemPrompt() {
        return """
                Jestes analitykiem okazji z rynku elektroniki na OLX.
                Oceniasz uszkodzone lub podejrzane oferty.
                Szukasz tego, co faktycznie moze byc zepsute, co prawdopodobnie nadal ma wartosc,
                jak trudna jest naprawa oraz jaka neutralna fraza najlepiej nadaje sie do wyszukania zdrowych odpowiednikow.
                Zwracaj odpowiedz tylko jako poprawny JSON zgodny ze schema.
                Nie wymyslaj faktow. Jezeli opis jest niejednoznaczny, obniz confidence.
                Odpowiadaj po polsku bez markdown.
                """;
    }

    private String buildPrompt(ListingDetails listingDetails) {
        StringBuilder builder = new StringBuilder();
        builder.append("Tytul: ").append(listingDetails.summary().title()).append('\n');
        builder.append("Cena: ").append(listingDetails.summary().price()).append(" PLN\n");
        builder.append("Lokalizacja: ").append(listingDetails.summary().location()).append('\n');
        builder.append("Stan z listingu: ").append(listingDetails.summary().condition()).append("\n\n");
        builder.append("Opis:\n").append(listingDetails.description()).append("\n\n");
        builder.append("Parametry:\n");
        listingDetails.parameters().forEach((key, value) -> builder.append("- ").append(key).append(": ").append(value).append('\n'));
        return builder.toString();
    }

    private ObjectNode buildTextFormat() {
        ObjectNode root = objectMapper.createObjectNode();
        ObjectNode format = root.putObject("format");
        format.put("type", "json_schema");
        format.put("name", "electronics_damage_assessment");
        format.put("strict", true);
        format.set("schema", buildSchema());
        return root;
    }

    private ObjectNode buildSchema() {
        ObjectNode schema = objectMapper.createObjectNode();
        schema.put("type", "object");
        schema.put("additionalProperties", false);

        ObjectNode properties = schema.putObject("properties");
        properties.putObject("canonicalProductName").put("type", "string");
        properties.putObject("productSearchQuery").put("type", "string");
        properties.putObject("damageSummary").put("type", "string");
        properties.set("likelyFaults", stringArraySchema());
        properties.set("workingValuePoints", stringArraySchema());
        properties.putObject("repairability").put("type", "string");
        properties.putObject("repairCostMinPln").put("type", "integer");
        properties.putObject("repairCostMaxPln").put("type", "integer");
        properties.putObject("confidence").put("type", "string");
        properties.set("redFlags", stringArraySchema());
        properties.putObject("notes").put("type", "string");

        ArrayNode required = schema.putArray("required");
        required.add("canonicalProductName");
        required.add("productSearchQuery");
        required.add("damageSummary");
        required.add("likelyFaults");
        required.add("workingValuePoints");
        required.add("repairability");
        required.add("repairCostMinPln");
        required.add("repairCostMaxPln");
        required.add("confidence");
        required.add("redFlags");
        required.add("notes");

        return schema;
    }

    private ObjectNode stringArraySchema() {
        ObjectNode node = objectMapper.createObjectNode();
        node.put("type", "array");
        node.putObject("items").put("type", "string");
        return node;
    }

    private AiAssessment heuristicAssessment(ListingDetails listingDetails, String note) {
        String combined = (listingDetails.summary().title() + " " + listingDetails.description()).toLowerCase(Locale.ROOT);
        List<String> likelyFaults = new ArrayList<>();
        List<String> workingValuePoints = new ArrayList<>();
        List<String> redFlags = new ArrayList<>();

        int repairMin = 80;
        int repairMax = 250;
        String repairability = "MODERATE";

        if (combined.contains("graf")) {
            likelyFaults.add("Mozliwa awaria ukladu graficznego lub toru obrazu.");
            repairMin = 150;
            repairMax = 400;
            repairability = "HARD";
        }
        if (combined.contains("matryc") || combined.contains("ekran")) {
            likelyFaults.add("Mozliwa usterka matrycy, tasmy sygnalowej albo podswietlenia.");
            repairMin = Math.min(repairMin, 100);
            repairMax = Math.max(repairMax, 300);
        }
        if (combined.contains("nie wlacza") || combined.contains("nie uruchamia")) {
            likelyFaults.add("Mozliwy problem z zasilaniem, plyta glowna albo bateria.");
            repairMin = 120;
            repairMax = 450;
            repairability = "HARD";
        }
        if (combined.contains("pek")) {
            redFlags.add("Opis wspomina o uszkodzeniach mechanicznych.");
        }
        if (combined.contains("sprawne") || combined.contains("dziala")) {
            workingValuePoints.add("Sprzedajacy deklaruje, ze czesc funkcji nadal dziala.");
        }
        if (combined.contains("ssd")) {
            workingValuePoints.add("Opis sugeruje, ze dysk SSD nadal ma wartosc.");
        }
        if (combined.contains("zasilacz")) {
            workingValuePoints.add("W zestawie jest zasilacz, co zwieksza wartosc czesci.");
        }
        if (likelyFaults.isEmpty()) {
            likelyFaults.add("Opis jest niejednoznaczny, mozliwa usterka trudna do potwierdzenia bez testow.");
            redFlags.add("Za malo jednoznacznych danych o awarii.");
        }

        String productQuery = fallbackSearchQuery(listingDetails.summary().title());
        String canonicalProductName = productQuery.isBlank() ? listingDetails.summary().title() : productQuery;

        return normalizeAssessment(new AiAssessment(
                canonicalProductName,
                productQuery,
                "Ocena heurystyczna na podstawie tytulu i opisu.",
                likelyFaults,
                workingValuePoints,
                repairability,
                repairMin,
                Math.max(repairMin, repairMax),
                "LOW",
                redFlags,
                note
        ), listingDetails, note);
    }

    private AiAssessment normalizeAssessment(AiAssessment raw, ListingDetails listingDetails, String note) {
        String fallbackQuery = fallbackSearchQuery(listingDetails.summary().title());
        String canonicalName = blankToFallback(raw.canonicalProductName(), listingDetails.summary().title());
        String productSearchQuery = blankToFallback(raw.productSearchQuery(), fallbackQuery);
        String damageSummary = blankToFallback(raw.damageSummary(), "Brak podsumowania uszkodzenia.");
        String repairability = blankToFallback(raw.repairability(), "UNKNOWN").toUpperCase(Locale.ROOT);
        String confidence = blankToFallback(raw.confidence(), "LOW").toUpperCase(Locale.ROOT);

        List<String> likelyFaults = sanitizeList(raw.likelyFaults(), "Brak pewnych tropow poza samym tytulem.");
        List<String> workingValuePoints = sanitizeList(raw.workingValuePoints(), "Opis nie daje mocnych sygnalow o sprawnych podzespolach.");
        List<String> redFlags = sanitizeList(raw.redFlags(), "Ryzyko wynika glownie z niepelnego opisu.");

        int repairMin = Math.max(0, raw.repairCostMinPln());
        int repairMax = Math.max(repairMin, raw.repairCostMaxPln());
        String notes = blankToFallback(raw.notes(), note);

        return new AiAssessment(
                canonicalName,
                productSearchQuery,
                damageSummary,
                likelyFaults,
                workingValuePoints,
                repairability,
                repairMin,
                repairMax,
                confidence,
                redFlags,
                notes
        );
    }

    private List<String> sanitizeList(List<String> values, String fallback) {
        if (values == null || values.isEmpty()) {
            return List.of(fallback);
        }

        List<String> sanitized = values.stream()
                .filter(value -> value != null && !value.isBlank())
                .toList();
        return sanitized.isEmpty() ? List.of(fallback) : sanitized;
    }

    private String blankToFallback(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private String fallbackSearchQuery(String title) {
        String cleaned = TextSanitizer.cleanProductSearchQuery(title);
        return cleaned.isBlank() ? title : cleaned;
    }
}
