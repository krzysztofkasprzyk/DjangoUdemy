package pl.olxsniper.service;

import pl.olxsniper.domain.ListingSummary;
import pl.olxsniper.domain.OpportunityReport;
import pl.olxsniper.util.Htmls;

import java.util.List;

public final class OpportunityFormatter {
    public String subjectFor(OpportunityReport report) {
        return "[" + report.verdict() + "] " + report.listing().summary().title();
    }

    public String format(OpportunityReport report) {
        StringBuilder builder = new StringBuilder();
        builder.append("<b>").append(report.verdict()).append(" - ").append(report.dealScore()).append("/100</b>\n");
        builder.append("<b>").append(Htmls.escape(report.listing().summary().title())).append("</b>\n");
        builder.append("Cena: <b>").append(report.listing().summary().price()).append(" PLN</b>\n");
        builder.append("Lokalizacja: <b>").append(Htmls.escape(report.listing().summary().location())).append("</b>\n");

        if (report.marketSnapshot().sampleSize() > 0) {
            builder.append("Rynek: mediana <b>")
                    .append((int) Math.round(report.marketSnapshot().medianPrice()))
                    .append(" PLN</b> z ")
                    .append(report.marketSnapshot().sampleSize())
                    .append(" podobnych ofert\n");
        } else {
            builder.append("Rynek: <b>brak pewnych porownan</b>\n");
        }

        builder.append("Naprawa: <b>")
                .append(report.assessment().repairCostMinPln())
                .append("-")
                .append(report.assessment().repairCostMaxPln())
                .append(" PLN</b>\n");
        builder.append("Wynik po naprawie: ostroznie <b>")
                .append(report.conservativeProfitPln())
                .append(" PLN</b>, optymistycznie <b>")
                .append(report.optimisticProfitPln())
                .append(" PLN</b>\n");
        builder.append("Fraza porownawcza: <code>")
                .append(Htmls.escape(report.assessment().productSearchQuery()))
                .append("</code>\n\n");

        builder.append("<b>Co moze byc uszkodzone</b>\n");
        appendLines(builder, report.assessment().likelyFaults(), 3);

        builder.append("\n<b>Co nadal moze miec wartosc</b>\n");
        appendLines(builder, report.assessment().workingValuePoints(), 3);

        builder.append("\n<b>AI podsumowanie</b>\n");
        builder.append(Htmls.escape(report.assessment().damageSummary())).append("\n");

        builder.append("\n<b>Ryzyka</b>\n");
        appendLines(builder, report.assessment().redFlags(), 3);

        if (!report.marketSnapshot().references().isEmpty()) {
            builder.append("\n<b>Przykladowe porownania</b>\n");
            List<ListingSummary> references = report.marketSnapshot().references().stream().limit(3).toList();
            for (ListingSummary reference : references) {
                builder.append("- ")
                        .append(reference.price())
                        .append(" PLN: <a href=\"")
                        .append(Htmls.escape(reference.url()))
                        .append("\">")
                        .append(Htmls.escape(reference.title()))
                        .append("</a>\n");
            }
        }

        builder.append("\n<a href=\"")
                .append(Htmls.escape(report.listing().summary().url()))
                .append("\">Otworz oferte</a>");

        String message = builder.toString();
        return message.length() > 3900 ? message.substring(0, 3890) + "..." : message;
    }

    private void appendLines(StringBuilder builder, List<String> values, int maxLines) {
        int count = 0;
        for (String value : values) {
            if (count >= maxLines) {
                break;
            }
            builder.append("- ").append(Htmls.escape(value)).append('\n');
            count++;
        }
    }
}
