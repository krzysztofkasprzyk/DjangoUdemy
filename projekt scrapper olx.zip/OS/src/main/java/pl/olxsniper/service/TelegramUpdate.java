package pl.olxsniper.service;

public record TelegramUpdate(
        long updateId,
        long chatId,
        String text
) {
}
