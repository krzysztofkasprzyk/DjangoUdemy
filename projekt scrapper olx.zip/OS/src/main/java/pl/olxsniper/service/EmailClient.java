package pl.olxsniper.service;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import pl.olxsniper.config.EmailSettings;

import java.nio.charset.StandardCharsets;
import java.util.Properties;

public final class EmailClient {
    private final EmailSettings settings;

    public EmailClient(EmailSettings settings) {
        this.settings = settings;
    }

    public void sendHtmlMessage(String subject, String html) {
        try {
            Session session = Session.getInstance(buildProperties(), buildAuthenticator());
            MimeMessage message = new MimeMessage(session);

            message.setFrom(new InternetAddress(settings.from()));
            for (String recipient : settings.recipients()) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            }

            message.setSubject(subject, StandardCharsets.UTF_8.name());
            message.setContent(html, "text/html; charset=UTF-8");
            Transport.send(message);
        } catch (Exception exception) {
            throw new IllegalStateException("Nie udalo sie wyslac e-maila", exception);
        }
    }

    private Properties buildProperties() {
        Properties properties = new Properties();
        properties.put("mail.smtp.host", settings.host());
        properties.put("mail.smtp.port", Integer.toString(settings.port()));
        properties.put("mail.smtp.auth", Boolean.toString(settings.authEnabled()));
        properties.put("mail.smtp.starttls.enable", Boolean.toString(settings.startTls()));
        properties.put("mail.smtp.ssl.enable", Boolean.toString(settings.ssl()));
        return properties;
    }

    private Authenticator buildAuthenticator() {
        if (!settings.authEnabled()) {
            return null;
        }

        return new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(settings.username(), settings.password());
            }
        };
    }
}
