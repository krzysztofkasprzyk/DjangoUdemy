package pl.olxsniper.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import pl.olxsniper.config.ChatSettings;
import pl.olxsniper.domain.ListingDetails;
import pl.olxsniper.domain.ListingSummary;
import pl.olxsniper.domain.MarketSnapshot;
import pl.olxsniper.util.TextSanitizer;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public final class OlxClient {
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36";
    private static final String ELECTRONICS_BASE_URL = "https://www.olx.pl/elektronika/";

    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<ListingSummary> searchDamagedListings(ChatSettings settings, int limit) {
        Map<String, ListingSummary> merged = new LinkedHashMap<>();

        for (String keyword : settings.keywords()) {
            List<ListingSummary> listings = searchListings(keyword, limit * 2);
            for (ListingSummary listing : listings) {
                if (!matchesFilters(listing, settings)) {
                    continue;
                }

                merged.putIfAbsent(listing.url(), listing);
                if (merged.size() >= limit) {
                    return new ArrayList<>(merged.values());
                }
            }
        }

        return new ArrayList<>(merged.values());
    }

    public ListingDetails fetchListingDetails(ListingSummary summary) {
        Document document = fetch(summary.url());
        JsonNode productNode = findProductNode(document).orElseThrow(
                () -> new IllegalStateException("Brak danych strukturalnych dla ogloszenia: " + summary.url())
        );

        String title = productNode.path("name").asText(summary.title());
        int price = productNode.path("offers").path("price").asInt(summary.price());
        String description = productNode.path("description").asText("");

        List<String> images = new ArrayList<>();
        JsonNode imageNode = productNode.path("image");
        if (imageNode.isArray()) {
            imageNode.forEach(node -> images.add(node.asText()));
        }

        Map<String, String> parameters = extractParameters(document);
        ListingSummary enrichedSummary = new ListingSummary(title, summary.url(), price, summary.location(), summary.condition());
        return new ListingDetails(enrichedSummary, description, parameters, images);
    }

    public MarketSnapshot buildMarketSnapshot(String query, int referenceLimit) {
        List<ListingSummary> listings = searchListings(query, referenceLimit * 4).stream()
                .filter(listing -> !TextSanitizer.containsDamageHint(listing.title()))
                .filter(listing -> TextSanitizer.looksRelevantToQuery(query, listing.title()))
                .limit(referenceLimit)
                .collect(Collectors.toList());

        if (listings.isEmpty()) {
            return new MarketSnapshot(query, 0, 0, 0, 0, 0, List.of());
        }

        List<Integer> prices = listings.stream()
                .map(ListingSummary::price)
                .sorted()
                .collect(Collectors.toList());

        double average = prices.stream().mapToInt(Integer::intValue).average().orElse(0);
        double median;
        int middle = prices.size() / 2;
        if (prices.size() % 2 == 0) {
            median = (prices.get(middle - 1) + prices.get(middle)) / 2.0;
        } else {
            median = prices.get(middle);
        }

        return new MarketSnapshot(
                query,
                listings.size(),
                average,
                median,
                prices.get(0),
                prices.get(prices.size() - 1),
                listings
        );
    }

    private boolean matchesFilters(ListingSummary listing, ChatSettings settings) {
        if (settings.priceFrom() != null && listing.price() < settings.priceFrom()) {
            return false;
        }
        if (settings.priceTo() != null && listing.price() > settings.priceTo()) {
            return false;
        }

        String locationFilter = settings.locationFilter();
        if (locationFilter != null && !locationFilter.isBlank()) {
            String location = listing.location() == null ? "" : listing.location().toLowerCase(Locale.ROOT);
            if (!location.contains(locationFilter)) {
                return false;
            }
        }

        return true;
    }

    private List<ListingSummary> searchListings(String query, int limit) {
        String url = ELECTRONICS_BASE_URL + "q-" + TextSanitizer.toOlxQuerySlug(query) + "/";
        Document document = fetch(url);
        JsonNode aggregateOfferNode = findAggregateOfferNode(document).orElse(null);

        if (aggregateOfferNode == null) {
            return List.of();
        }

        List<ListingSummary> listings = new ArrayList<>();
        JsonNode offersNode = aggregateOfferNode.path("offers").path("offers");
        if (!offersNode.isArray()) {
            return List.of();
        }

        for (JsonNode offer : offersNode) {
            String title = offer.path("name").asText("");
            String offerUrl = offer.path("url").asText("");
            int price = offer.path("price").asInt(0);
            String location = offer.path("areaServed").path("name").asText("");
            String condition = simplifyCondition(offer.path("itemCondition").asText(""));

            if (title.isBlank() || offerUrl.isBlank() || price <= 0) {
                continue;
            }

            listings.add(new ListingSummary(title, offerUrl, price, location, condition));
            if (listings.size() >= limit) {
                break;
            }
        }

        return listings;
    }

    private Document fetch(String url) {
        try {
            return Jsoup.connect(url)
                    .userAgent(USER_AGENT)
                    .timeout((int) Duration.ofSeconds(30).toMillis())
                    .get();
        } catch (IOException exception) {
            throw new IllegalStateException("Nie udalo sie pobrac strony OLX: " + url, exception);
        }
    }

    private Optional<JsonNode> findAggregateOfferNode(Document document) {
        for (Element script : document.select("script[type=application/ld+json]")) {
            JsonNode root = parseJson(script.data());
            if (root == null || !root.isObject()) {
                continue;
            }

            if ("Product".equals(root.path("@type").asText())
                    && "AggregateOffer".equals(root.path("offers").path("@type").asText())) {
                return Optional.of(root);
            }
        }
        return Optional.empty();
    }

    private Optional<JsonNode> findProductNode(Document document) {
        for (Element script : document.select("script[type=application/ld+json]")) {
            JsonNode root = parseJson(script.data());
            if (root == null || !root.isObject()) {
                continue;
            }

            if ("Product".equals(root.path("@type").asText())
                    && "Offer".equals(root.path("offers").path("@type").asText())) {
                return Optional.of(root);
            }
        }
        return Optional.empty();
    }

    private Map<String, String> extractParameters(Document document) {
        Map<String, String> parameters = new LinkedHashMap<>();
        Elements entries = document.select("p[data-nx-name=P3]");

        for (Element entry : entries) {
            String text = entry.text().trim();
            if (!text.contains(":")) {
                continue;
            }

            String[] parts = text.split(":", 2);
            String key = parts[0].trim();
            String value = parts[1].trim();
            if (key.isBlank() || value.isBlank()) {
                continue;
            }

            parameters.putIfAbsent(key, value);
        }

        return parameters;
    }

    private JsonNode parseJson(String rawJson) {
        try {
            return objectMapper.readTree(rawJson);
        } catch (Exception exception) {
            return null;
        }
    }

    private String simplifyCondition(String rawCondition) {
        if (rawCondition == null || rawCondition.isBlank()) {
            return "unknown";
        }

        int lastSlash = rawCondition.lastIndexOf('/');
        return lastSlash >= 0 ? rawCondition.substring(lastSlash + 1) : rawCondition;
    }
}
