package pl.olxsniper.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class TelegramClient {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(20))
            .build();
    private final String baseUrl;

    public TelegramClient(String token) {
        this.baseUrl = "https://api.telegram.org/bot" + token;
    }

    public List<TelegramUpdate> getUpdates(long offset, int timeoutSeconds) throws IOException, InterruptedException {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("offset", Long.toString(offset));
        form.put("timeout", Integer.toString(timeoutSeconds));
        form.put("allowed_updates", "[\"message\"]");

        JsonNode root = postForm("getUpdates", form);
        List<TelegramUpdate> updates = new ArrayList<>();

        for (JsonNode item : root.path("result")) {
            JsonNode message = item.path("message");
            JsonNode chat = message.path("chat");
            if (!chat.hasNonNull("id") || !message.hasNonNull("text")) {
                continue;
            }

            updates.add(new TelegramUpdate(
                    item.path("update_id").asLong(),
                    chat.path("id").asLong(),
                    message.path("text").asText()
            ));
        }

        return updates;
    }

    public void sendHtmlMessage(long chatId, String html) {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("chat_id", Long.toString(chatId));
        form.put("text", html);
        form.put("parse_mode", "HTML");
        form.put("disable_web_page_preview", "true");

        try {
            postForm("sendMessage", form);
        } catch (Exception exception) {
            throw new IllegalStateException("Nie udalo sie wyslac wiadomosci do Telegrama", exception);
        }
    }

    private JsonNode postForm(String method, Map<String, String> formData) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(baseUrl + "/" + method))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .timeout(Duration.ofSeconds(40))
                .POST(HttpRequest.BodyPublishers.ofString(encodeForm(formData)))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        JsonNode root = objectMapper.readTree(response.body());

        if (!root.path("ok").asBoolean()) {
            throw new IllegalStateException(root.path("description").asText("Telegram API error"));
        }

        return root;
    }

    private String encodeForm(Map<String, String> formData) {
        return formData.entrySet().stream()
                .map(entry -> URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8)
                        + "="
                        + URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8))
                .reduce((left, right) -> left + "&" + right)
                .orElse("");
    }
}
