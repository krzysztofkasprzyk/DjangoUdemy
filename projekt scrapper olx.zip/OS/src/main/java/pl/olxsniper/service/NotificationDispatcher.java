package pl.olxsniper.service;

import pl.olxsniper.config.NotificationMode;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public final class NotificationDispatcher {
    private static final Logger LOGGER = Logger.getLogger(NotificationDispatcher.class.getName());

    private final NotificationMode mode;
    private final TelegramClient telegramClient;
    private final EmailClient emailClient;

    public NotificationDispatcher(NotificationMode mode, TelegramClient telegramClient, EmailClient emailClient) {
        this.mode = mode;
        this.telegramClient = telegramClient;
        this.emailClient = emailClient;
    }

    public void sendAlert(long chatId, String subject, String html) {
        boolean delivered = false;
        List<String> errors = new ArrayList<>();

        if (mode.includesTelegram()) {
            try {
                if (telegramClient == null) {
                    throw new IllegalStateException("Telegram client nie jest skonfigurowany.");
                }
                if (chatId <= 0) {
                    throw new IllegalStateException("Brak poprawnego chatId dla Telegrama w trybie headless.");
                }
                telegramClient.sendHtmlMessage(chatId, html);
                LOGGER.info("Telegram alert sent.");
                delivered = true;
            } catch (Exception exception) {
                errors.add("telegram: " + exception.getMessage());
            }
        }

        if (mode.includesEmail()) {
            try {
                if (emailClient == null) {
                    throw new IllegalStateException("Email client nie jest skonfigurowany.");
                }
                emailClient.sendHtmlMessage(subject, html);
                LOGGER.info("Email alert sent with subject: " + subject);
                delivered = true;
            } catch (Exception exception) {
                errors.add("email: " + exception.getMessage());
            }
        }

        if (!delivered) {
            throw new IllegalStateException(String.join(" | ", errors));
        }
    }
}
