package pl.olxsniper;

import pl.olxsniper.config.AppConfig;

public final class Main {
    private Main() {
    }

    public static void main(String[] args) {
        AppConfig config = AppConfig.load();
        new DealHunterApplication(config).start();
    }
}
