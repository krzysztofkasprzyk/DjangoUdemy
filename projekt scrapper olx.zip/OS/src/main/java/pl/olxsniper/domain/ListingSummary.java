package pl.olxsniper.domain;

public record ListingSummary(
        String title,
        String url,
        int price,
        String location,
        String condition
) {
}
