package pl.olxsniper.domain;

public record OpportunityReport(
        ListingDetails listing,
        AiAssessment assessment,
        MarketSnapshot marketSnapshot,
        int dealScore,
        int conservativeProfitPln,
        int optimisticProfitPln,
        String verdict,
        boolean shouldNotify
) {
}
