package pl.olxsniper.domain;

import java.util.List;

public record MarketSnapshot(
        String searchQuery,
        int sampleSize,
        double averagePrice,
        double medianPrice,
        int minPrice,
        int maxPrice,
        List<ListingSummary> references
) {
}
