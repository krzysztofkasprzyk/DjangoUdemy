package pl.olxsniper.domain;

import java.util.List;

public record AiAssessment(
        String canonicalProductName,
        String productSearchQuery,
        String damageSummary,
        List<String> likelyFaults,
        List<String> workingValuePoints,
        String repairability,
        int repairCostMinPln,
        int repairCostMaxPln,
        String confidence,
        List<String> redFlags,
        String notes
) {
}
