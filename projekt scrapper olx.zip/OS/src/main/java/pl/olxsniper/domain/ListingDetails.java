package pl.olxsniper.domain;

import java.util.List;
import java.util.Map;

public record ListingDetails(
        ListingSummary summary,
        String description,
        Map<String, String> parameters,
        List<String> imageUrls
) {
}
