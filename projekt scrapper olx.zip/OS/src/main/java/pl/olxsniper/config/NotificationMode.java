package pl.olxsniper.config;

import java.util.Locale;

public enum NotificationMode {
    TELEGRAM,
    EMAIL,
    BOTH;

    public static NotificationMode from(String value) {
        return switch (value.toLowerCase(Locale.ROOT)) {
            case "telegram" -> TELEGRAM;
            case "email", "mail" -> EMAIL;
            case "both", "all" -> BOTH;
            default -> throw new IllegalArgumentException("Nieznany NOTIFICATION_CHANNEL: " + value);
        };
    }

    public boolean includesTelegram() {
        return this == TELEGRAM || this == BOTH;
    }

    public boolean includesEmail() {
        return this == EMAIL || this == BOTH;
    }
}
