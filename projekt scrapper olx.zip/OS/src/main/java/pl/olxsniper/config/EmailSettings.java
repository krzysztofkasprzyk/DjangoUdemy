package pl.olxsniper.config;

import java.util.Arrays;
import java.util.List;

public record EmailSettings(
        String host,
        int port,
        String username,
        String password,
        String from,
        List<String> recipients,
        boolean startTls,
        boolean ssl
) {
    public static EmailSettings fromEnv() {
        String host = required("SMTP_HOST");
        int port = Integer.parseInt(optional("SMTP_PORT", "587"));
        String username = optional("SMTP_USERNAME", "");
        String password = optional("SMTP_PASSWORD", "");
        String from = required("SMTP_FROM");
        List<String> recipients = Arrays.stream(required("ALERT_EMAIL_TO").split(","))
                .map(String::trim)
                .filter(value -> !value.isBlank())
                .toList();

        if (recipients.isEmpty()) {
            throw new IllegalStateException("ALERT_EMAIL_TO nie moze byc puste.");
        }

        return new EmailSettings(
                host,
                port,
                username,
                password,
                from,
                recipients,
                Boolean.parseBoolean(optional("SMTP_STARTTLS", "true")),
                Boolean.parseBoolean(optional("SMTP_SSL", "false"))
        );
    }

    public static EmailSettings disabled() {
        return new EmailSettings("", 587, "", "", "", List.of(), true, false);
    }

    public boolean authEnabled() {
        return username != null && !username.isBlank();
    }

    private static String required(String key) {
        String value = System.getenv(key);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Brak wymaganej zmiennej srodowiskowej: " + key);
        }
        return value.trim();
    }

    private static String optional(String key, String defaultValue) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? defaultValue : value.trim();
    }
}
