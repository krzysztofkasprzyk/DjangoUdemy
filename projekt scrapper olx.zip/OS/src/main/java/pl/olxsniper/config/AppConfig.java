package pl.olxsniper.config;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public record AppConfig(
        String telegramBotToken,
        boolean telegramPollingEnabled,
        boolean startupMonitoringEnabled,
        NotificationMode notificationMode,
        EmailSettings emailSettings,
        String openAiApiKey,
        String openAiModel,
        Duration scanInterval,
        Duration reconnectDelay,
        int telegramLongPollSeconds,
        int searchResultLimit,
        int marketReferenceLimit,
        int maxSeenOffers,
        List<String> defaultKeywords,
        Integer defaultPriceFrom,
        Integer defaultPriceTo,
        String defaultLocationFilter
) {
    public static AppConfig load() {
        String token = optionalNullableEnv("TELEGRAM_BOT_TOKEN");
        NotificationMode notificationMode = NotificationMode.from(optionalEnv("NOTIFICATION_CHANNEL", "telegram"));
        boolean telegramPollingEnabled = optionalBoolean(
                "TELEGRAM_POLLING_ENABLED",
                token != null && !token.isBlank() && notificationMode.includesTelegram()
        );
        boolean startupMonitoringEnabled = optionalBoolean("START_MONITORING_ON_BOOT", !telegramPollingEnabled);
        EmailSettings emailSettings = notificationMode.includesEmail() ? EmailSettings.fromEnv() : EmailSettings.disabled();

        if (notificationMode.includesTelegram() && (token == null || token.isBlank())) {
            throw new IllegalStateException("NOTIFICATION_CHANNEL wymaga Telegrama, ale TELEGRAM_BOT_TOKEN nie jest ustawiony.");
        }
        if (telegramPollingEnabled && (token == null || token.isBlank())) {
            throw new IllegalStateException("TELEGRAM_POLLING_ENABLED=true wymaga TELEGRAM_BOT_TOKEN.");
        }
        if (!telegramPollingEnabled && notificationMode == NotificationMode.TELEGRAM) {
            throw new IllegalStateException("Tryb telegram bez pollingu nie ma dokad wysylac alertow. Ustaw email albo both.");
        }

        return new AppConfig(
                token,
                telegramPollingEnabled,
                startupMonitoringEnabled,
                notificationMode,
                emailSettings,
                optionalEnv("OPENAI_API_KEY", ""),
                optionalEnv("OPENAI_MODEL", "gpt-5-mini"),
                Duration.ofSeconds(optionalInt("SCAN_INTERVAL_SECONDS", 90)),
                Duration.ofSeconds(optionalInt("RECONNECT_DELAY_SECONDS", 10)),
                optionalInt("TELEGRAM_LONG_POLL_SECONDS", 25),
                optionalInt("SEARCH_RESULT_LIMIT", 18),
                optionalInt("MARKET_REFERENCE_LIMIT", 8),
                optionalInt("MAX_SEEN_OFFERS", 500),
                parseKeywords(optionalEnv("DEFAULT_KEYWORDS", "uszkodzony,uszkodzona,uszkodzone,do naprawy,nietestowany,nietestowane")),
                optionalNullableInt("DEFAULT_PRICE_FROM", null),
                optionalNullableInt("DEFAULT_PRICE_TO", 1500),
                optionalNullableString("DEFAULT_LOCATION_FILTER", null)
        );
    }

    public boolean aiEnabled() {
        return openAiApiKey != null && !openAiApiKey.isBlank();
    }

    private static String requiredEnv(String key) {
        String value = System.getenv(key);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Brak wymaganej zmiennej srodowiskowej: " + key);
        }
        return value;
    }

    private static String optionalNullableEnv(String key) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? null : value.trim();
    }

    private static String optionalEnv(String key, String defaultValue) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? defaultValue : value;
    }

    private static boolean optionalBoolean(String key, boolean defaultValue) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? defaultValue : Boolean.parseBoolean(value);
    }

    private static int optionalInt(String key, int defaultValue) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? defaultValue : Integer.parseInt(value);
    }

    private static Integer optionalNullableInt(String key, Integer defaultValue) {
        String value = System.getenv(key);
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        if ("-".equals(value.trim())) {
            return null;
        }
        return Integer.parseInt(value.trim());
    }

    private static String optionalNullableString(String key, String defaultValue) {
        String value = System.getenv(key);
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        return "-".equals(value.trim()) ? null : value.trim().toLowerCase(Locale.ROOT);
    }

    private static List<String> parseKeywords(String csv) {
        return Arrays.stream(csv.split(","))
                .map(String::trim)
                .filter(value -> !value.isBlank())
                .map(value -> value.toLowerCase(Locale.ROOT))
                .distinct()
                .collect(Collectors.toList());
    }
}
