package pl.olxsniper.config;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class ChatSettings {
    private boolean active;
    private Integer priceFrom;
    private Integer priceTo;
    private String locationFilter;
    private List<String> keywords;

    public ChatSettings(AppConfig config) {
        this.active = false;
        this.priceFrom = config.defaultPriceFrom();
        this.priceTo = config.defaultPriceTo();
        this.locationFilter = config.defaultLocationFilter();
        this.keywords = List.copyOf(config.defaultKeywords());
    }

    public boolean active() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Integer priceFrom() {
        return priceFrom;
    }

    public void setPriceFrom(Integer priceFrom) {
        this.priceFrom = priceFrom;
    }

    public Integer priceTo() {
        return priceTo;
    }

    public void setPriceTo(Integer priceTo) {
        this.priceTo = priceTo;
    }

    public String locationFilter() {
        return locationFilter;
    }

    public void setLocationFilter(String locationFilter) {
        this.locationFilter = locationFilter == null ? null : locationFilter.trim().toLowerCase(Locale.ROOT);
    }

    public List<String> keywords() {
        return keywords;
    }

    public void setKeywordsFromCsv(String csv) {
        List<String> parsed = Arrays.stream(csv.split(","))
                .map(String::trim)
                .filter(value -> !value.isBlank())
                .map(value -> value.toLowerCase(Locale.ROOT))
                .distinct()
                .collect(Collectors.toList());

        if (parsed.isEmpty()) {
            throw new IllegalArgumentException("Lista fraz nie moze byc pusta.");
        }

        this.keywords = List.copyOf(parsed);
    }

    public String keywordsAsDisplayString() {
        return String.join(", ", keywords);
    }

    public String locationDisplayValue() {
        return locationFilter == null || locationFilter.isBlank() ? "brak" : locationFilter;
    }
}
