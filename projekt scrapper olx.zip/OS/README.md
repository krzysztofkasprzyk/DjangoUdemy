# OLX Electro Hunter

OLX Electro Hunter to bot Telegramowy do polowania na okazje w kategorii elektronika na OLX.

Projekt szuka ogloszen typu:
- uszkodzony
- do naprawy
- nietestowany

Nastepnie:
- pobiera szczegoly oferty z aktualnego HTML/JSON-LD OLX,
- analizuje opis przez OpenAI Responses API,
- probuje wywnioskowac co moze byc zepsute,
- buduje fraze do szukania zdrowych odpowiednikow,
- porownuje cene do podobnych ofert rynkowych,
- wysyla alert na Telegram, e-mail albo oba kanaly tylko wtedy, gdy oferta wyglada na mocna okazje.

## Co sie zmienilo wzgledem starej wersji

Stara wersja byla scraperem mieszkan opartym o HtmlUnit i stare API biblioteki Telegram.

Nowa wersja:
- jest napisana pod Java 21,
- korzysta z `jsoup` i danych strukturalnych JSON-LD osadzonych na OLX,
- nie zalezy od starej biblioteki Telegram Bots,
- integruje sie bezposrednio z Telegram Bot API przez HTTP,
- uzywa OpenAI Responses API do analizy opisow uszkodzen,
- porownuje oferte do zdrowych odpowiednikow w kategorii elektronika.

## Wymagania

- Java 21
- Maven 3.9+
- bot Telegram z tokenem, jesli chcesz korzystac z Telegrama
- klucz API OpenAI

## Konfiguracja

Aplikacja czyta konfiguracje ze zmiennych srodowiskowych.

Wymagane:
- `TELEGRAM_BOT_TOKEN` tylko gdy uzywasz Telegrama albo polling Telegrama

Opcjonalne, ale zalecane:
- `NOTIFICATION_CHANNEL`
- `TELEGRAM_POLLING_ENABLED`
- `START_MONITORING_ON_BOOT`
- `OPENAI_API_KEY`
- `OPENAI_MODEL`
- `SCAN_INTERVAL_SECONDS`
- `DEFAULT_KEYWORDS`
- `DEFAULT_PRICE_FROM`
- `DEFAULT_PRICE_TO`
- `DEFAULT_LOCATION_FILTER`
- `SEARCH_RESULT_LIMIT`
- `MARKET_REFERENCE_LIMIT`
- `MAX_SEEN_OFFERS`
- `SMTP_HOST`
- `SMTP_PORT`
- `SMTP_USERNAME`
- `SMTP_PASSWORD`
- `SMTP_FROM`
- `ALERT_EMAIL_TO`
- `SMTP_STARTTLS`
- `SMTP_SSL`

Przyklad znajduje sie w `.env.example`.

### Wybor kanalu powiadomien

Ustaw `NOTIFICATION_CHANNEL` na jedna z wartosci:
- `telegram`
- `email`
- `both`

Przyklady:

Powiadomienia tylko na Telegram:

```env
NOTIFICATION_CHANNEL=telegram
TELEGRAM_POLLING_ENABLED=true
```

Powiadomienia tylko na e-mail, bez Telegrama:

```env
NOTIFICATION_CHANNEL=email
TELEGRAM_POLLING_ENABLED=false
START_MONITORING_ON_BOOT=true
SMTP_HOST=smtp.office365.com
SMTP_PORT=587
SMTP_FROM=twoj_adres@firma.com
ALERT_EMAIL_TO=twoj_adres@firma.com
SMTP_USERNAME=twoj_adres@firma.com
SMTP_PASSWORD=twoje_haslo_lub_app_password
SMTP_STARTTLS=true
SMTP_SSL=false
```

Powiadomienia jednoczesnie na Telegram i e-mail:

```env
NOTIFICATION_CHANNEL=both
TELEGRAM_POLLING_ENABLED=true
```

## Uruchomienie

1. Ustaw zmienne srodowiskowe.
2. Zbuduj projekt:

```bash
mvn clean package
```

3. Uruchom:

```bash
java -jar target/olx-electro-hunter-2.0.0.jar
```

### Szybki start na Windows

Masz dwa gotowe skrypty:

- `run-email-only.ps1` - uruchamia juz skonfigurowany tryb mail-only
- `start-hunter-anywhere.ps1` - najpierw sprawdza Java 21 i Maven, w razie potrzeby je przygotowuje, a potem uruchamia `run-email-only.ps1`

Na innym komputerze Windows najprosciej uruchomic:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-hunter-anywhere.ps1
```

## Komendy Telegrama

- `/start` - wlacza monitoring
- `/stop` - zatrzymuje monitoring
- `/status` - pokazuje aktualne ustawienia
- `/scan` - odpala reczny skan
- `/setup keywords uszkodzony,do naprawy,nietestowany` - ustawia frazy
- `/setup priceFrom 100` - ustawia minimalna cene
- `/setup priceTo 1200` - ustawia maksymalna cene
- `/setup location warszawa` - filtruje po lokalizacji
- `/setup location -` - czysci filtr lokalizacji

## Jak wyglada scoring okazji

Bot bierze pod uwage:
- cene ofertowa,
- szacowany koszt naprawy,
- mediane cen podobnych zdrowych ofert,
- liczbe referencji rynkowych,
- poziom ryzyka i pewnosci z analizy AI,
- sygnaly, ze pewne komponenty nadal maja wartosc.

Alert pojawia sie dopiero wtedy, gdy wynik jest na tyle wysoki, zeby traktowac oferte jako realna okazje, a nie tylko tani zlomek.

## Ograniczenia

- OLX moze zmienic strukture strony i wtedy parser trzeba dostosowac.
- Bot nie zapisuje jeszcze stanu do bazy, wiec restart czysci pamiec widzianych ofert.
- Gdy `OPENAI_API_KEY` nie jest ustawiony, aplikacja dziala w trybie heurystycznym bez prawdziwej analizy modelu.
- W trybie `email` bez Telegrama aplikacja startuje w trybie headless i korzysta tylko z ustawien z env.
